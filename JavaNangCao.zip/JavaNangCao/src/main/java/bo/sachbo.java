package bo;

import java.util.ArrayList;

import bean.sachbean;
import dao.sachdao;

public class sachbo {
	sachdao sdao = new sachdao();
	ArrayList<sachbean> ds;
	public ArrayList<sachbean> getsach(){
		ds = sdao.getsach();
		return ds;
	}
	public ArrayList<sachbean> TimMa(String maloai)
	{	
		ArrayList<sachbean> tam = new ArrayList<sachbean>();
		for(sachbean s: ds)
		{
			if(s.getMaloai().equals(maloai))
				tam.add(s);
		}
		return tam;
	}
	public ArrayList<sachbean> Tim(String key)
	{	
		ArrayList<sachbean> tam = new ArrayList<sachbean>();
		for(sachbean s: ds)
		{
			if(s.getTensach().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getMaloai().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getTacgia().toLowerCase().trim().contains(key.toLowerCase().trim()))
				tam.add(s);
		}
		return tam;
	}
	public void addsach(sachbean s) {
		sdao.addsach(s);
	 }
	public void xoasach(String masach) {
		sdao.xoasach(masach);
	}
	public sachbean timsach(String key)
	{
		return sdao.Timsach(key);
	}
	public void suasach(sachbean s) {
		 sdao.update(s);
	 }
}
