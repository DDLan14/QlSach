package bean;

public class chitiethoadonbean {
	private String machitiethd;
	private String masach;
	private long soluong;
	private String mahd;
	private boolean damua;
	
	
	
	
	
	public chitiethoadonbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public chitiethoadonbean(String masach, long soluong, String mahd, boolean damua) {
		super();
		this.masach = masach;
		this.soluong = soluong;
		this.mahd = mahd;
		this.damua = damua;
	}
	public String getMachitiethd() {
		return machitiethd;
	}
	public void setMachitiethd(String machitiethd) {
		this.machitiethd = machitiethd;
	}
	public String getMasach() {
		return masach;
	}
	public void setMasach(String masach) {
		this.masach = masach;
	}
	public long getSoluong() {
		return soluong;
	}
	public void setSoluong(long soluong) {
		this.soluong = soluong;
	}
	public String getMahd() {
		return mahd;
	}
	public void setMahd(String mahd) {
		this.mahd = mahd;
	}
	public boolean getDamua() {
		return damua;
	}
	public void setDamua(boolean damua) {
		this.damua = damua;
	}

	
}
