package bo;

import java.util.ArrayList;

import dao.lichsudao;
import bean.lichsubean;


public class lichsubo {
	lichsudao lsdao= new lichsudao();
	 ArrayList<lichsubean> ds= new ArrayList<lichsubean>();
	 
	 public ArrayList<lichsubean> getkh(String key){
		 ds=lsdao.getlichsu(key);
		 return ds;
	 }
	
}