package bean;

public class lichsubean {
	private String makh;
	private String tensach;
	private long SoLuongMua;
	private long gia;
	private Long ThanhToan;
	private boolean damua;
	public lichsubean(String makh, String tensach, Long soLuongMua,Long gia, Long thanhToan, boolean damua) {
		super();
		this.makh = makh;
		this.tensach = tensach;
		this.SoLuongMua = soLuongMua;
		this.gia= gia;
		ThanhToan = thanhToan;
		this.damua = damua;
	}
	public lichsubean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMakh() {
		return makh;
	}
	public void setMakh(String makh) {
		this.makh = makh;
	}
	public String getTensach() {
		return tensach;
	}
	public void setTensach(String tensach) {
		this.tensach = tensach;
	}
	public Long getSoLuongMua() {
		return SoLuongMua;
	}
	public void setSoLuongMua(Long soLuongMua) {
		SoLuongMua = soLuongMua;
	}
	public Long getThanhToan() {
		return ThanhToan;
	}
	public void setThanhToan(Long thanhToan) {
		ThanhToan = thanhToan;
	}
	public boolean isDamua() {
		return damua;
	}
	public void setDamua(boolean damua) {
		this.damua = damua;
	}
	public long getGia() {
		return gia;
	}
	public void setGia(long gia) {
		this.gia = gia;
	}
	public void setSoLuongMua(long soLuongMua) {
		SoLuongMua = soLuongMua;
	}
	
	
}