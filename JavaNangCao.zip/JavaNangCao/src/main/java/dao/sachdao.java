package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.loaibean;
import bean.sachbean;

public class sachdao {
	
	ArrayList<sachbean> dssach= new ArrayList<sachbean>();
	   public ArrayList<sachbean> getsach(){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				String sql="select * from sach";
				PreparedStatement cmd= cs.cn.prepareStatement(sql);
				ResultSet rs= cmd.executeQuery();
				//B3 Duyet qua du lieu va lay ve
				while(rs.next()) {
					String masach=rs.getString("masach");
					String tensach=rs.getString("tensach");
					String tacgia=rs.getString("tacgia");
					long soluong=rs.getLong("soluong");
					long gia=rs.getLong("gia");;
					String anh=rs.getString("anh");
					String maloai=rs.getString("maloai");
					String sotap=rs.getString("sotap");
					dssach.add(new sachbean(masach, tensach, tacgia, soluong, gia, anh, maloai, sotap));
				}
				//B4 Dong rs vaf cn
				rs.close();
				cs.cn.close();
				return dssach;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	   }
	public ArrayList<sachbean> TimMa(String maloai)
	{	
		ArrayList<sachbean> tam = new ArrayList<sachbean>();
		ArrayList<sachbean> ds= getsach();
		for(sachbean s: ds)
		{
			if(s.getMaloai().equals(maloai))
				tam.add(s);
		}
		return tam;
	}
	public ArrayList<sachbean> Tim(String key)
	{	
		ArrayList<sachbean> tam = new ArrayList<sachbean>();
		ArrayList<sachbean> ds= getsach();
		for(sachbean s: ds)
		{
			if(s.getTensach().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getMaloai().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getTacgia().toLowerCase().trim().contains(key.toLowerCase().trim()))
				tam.add(s);
		}
		return tam;
	}
	public sachbean Timsach(String key)
	{
		ArrayList<sachbean> ds= getsach();
		sachbean sb = new sachbean();
		for(sachbean s: ds)
		{
			if(s.getMasach().equals(key))
				sb = s;
		}
		return sb;
	}
	public void addsach(sachbean s){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				PreparedStatement stmt = cs.cn.prepareStatement("INSERT INTO sach(masach, tensach, soluong,gia,maloai,sotap,anh,NgayNhap,tacgia) VALUES (?, ?, ? , ? , ?, ?,?,?,?)");

				stmt.setString(1, s.getMasach());
				stmt.setString(2, s.getTensach());
				stmt.setLong(3, s.getSoluong());
				stmt.setLong(4, s.getGia());
				stmt.setString(5, s.getMaloai());
				stmt.setString(6, "1");
				stmt.setString(7, s.getAnh());
				stmt.setString(8,null);
				stmt.setString(9, s.getTacgia());
				stmt.executeUpdate();
				//B4 Dong rs vaf cn
				cs.cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	  }
	public void xoasach(String masach)
	{
		try {
				CoSodao cs = new CoSodao();
				cs.ketnoi();
				PreparedStatement stmt = cs.cn.prepareStatement("delete from sach where masach=?");
				
				stmt.setString(1,masach);
				stmt.executeUpdate();
				cs.cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void update(sachbean sb) {
		try {
			CoSodao cs= new CoSodao();
			cs.ketnoi();
			//B2 lay du lieu ve
			PreparedStatement stmt = cs.cn.prepareStatement("update sach set tensach= ?, soluong=? , gia=?, maloai=?, tacgia=?, sotap=? where masach=?");				
			stmt.setString(1, sb.getTensach());
			stmt.setLong(2, sb.getSoluong());
			stmt.setLong(3, sb.getGia());
			stmt.setString(4, sb.getMaloai());
			stmt.setString(5, sb.getTacgia());
			stmt.setString(6, sb.getSotap());
			stmt.setString(7, sb.getMasach());
			stmt.executeUpdate();
			//ResultSet rs= stmt.executeQuery();
			//B4 Dong rs vaf cn
			//rs.close();
			cs.cn.close();
			
		} catch (Exception e) {
			e.printStackTrace();

		}
		
	}
}
