package Controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.khachhangbean;
import bean.dangnhapAdminbean;
import bo.dangnhapAdminbo;

/**
 * Servlet implementation class ktdnAdminController
 */
@WebServlet("/ktdnAdminController")
public class ktdnAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ktdnAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String un = request.getParameter("txtun") ;
		String p = request.getParameter("txtpass");
		dangnhapAdminbo kh = new dangnhapAdminbo();
	//	dangnhapAdminbean dn=null;
		dangnhapAdminbean khlogin=kh.ktdn(un, p);
		if(khlogin!=null)
		{
		//Tao doi tuong session
		HttpSession session = request.getSession();
		
		//if(session.getAttribute("dn")==null)
			session.setAttribute("admin", khlogin);
			response.sendRedirect("adminController");
		}
//			RequestDispatcher rd = request.getRequestDispatcher("sach");
//			rd.forward(request, response);
		else {
			response.sendRedirect("dangnhapAdmin");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}