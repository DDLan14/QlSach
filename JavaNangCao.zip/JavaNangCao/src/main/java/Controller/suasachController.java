package Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.sachbean;
import bo.sachbo;
/**
 * Servlet implementation class suasachController
 */
@WebServlet("/suasachController")
public class suasachController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public suasachController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		DiskFileItemFactory factory = new DiskFileItemFactory();
		DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(fileItemFactory);
		String masach = null;
		String tensach = null;
		long soluong = 0;
		long gia = 0;
		String maloai = null;
		String tacgia = null;
		String sotap = null;
		try {
			List<FileItem> fileItems = upload.parseRequest(request);//Láº¥y vá»� cĂ¡c Ä‘á»‘i tÆ°á»£ng gá»­i lĂªn
			//duyá»‡t qua cĂ¡c Ä‘á»‘i tÆ°á»£ng gá»­i lĂªn tá»« client gá»“m file vĂ  cĂ¡c control
			for (FileItem fileItem : fileItems) {
				String tentk=fileItem.getFieldName();
				
				
				if(tentk.equals("masach")) masach=fileItem.getString();
				if(tentk.equals("tensach")) tensach = fileItem.getString();
				if(tentk.equals("soluong")) soluong = Long.parseLong(fileItem.getString());
				if(tentk.equals("gia")) gia = Long.parseLong(fileItem.getString());
				if(tentk.equals("maloai")) maloai = fileItem.getString();
				if(tentk.equals("tacgia")) tacgia = fileItem.getString();
				if(tentk.equals("sotap")) sotap = fileItem.getString();
				
			}
			response.getWriter().println(masach);
			sachbean sb= new sachbean(masach, tensach, tacgia, soluong, gia, null, maloai,sotap);
			sachbo sbo= new sachbo();
			sbo.suasach(sb);
			response.sendRedirect("themsachController");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
