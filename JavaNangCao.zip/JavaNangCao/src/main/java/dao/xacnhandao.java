package dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.xacnhanbean;


public class xacnhandao {

	public static ArrayList<xacnhanbean> getxacnhan(){
	  ArrayList<xacnhanbean> ds = new ArrayList<xacnhanbean>();
		try {
			//B1 Ket noi csdl
			CoSodao cs= new CoSodao();
			cs.ketnoi();
			//B2 lay du lieu ve
			String sql="select * from VXacNhan";
			PreparedStatement cmd= cs.cn.prepareStatement(sql);
			ResultSet rs= cmd.executeQuery();
			//B3 Duyet qua du lieu va lay ve
			while(rs.next()) {
				String makh=rs.getString("makh");
				String MaHoaDon=rs.getString("MaHoaDon");
				String MaChiTietHD=rs.getString("MaChiTietHD");
				String hoten=rs.getString("hoten");
				String tensach=rs.getString("tensach");
				Long SoLuongMua=rs.getLong("SoLuongMua");
				Long gia=rs.getLong("gia");
				Long ThanhTien=rs.getLong("ThanhTien");			
				Date NgayMua =rs.getDate("NgayMua");
				Boolean damua=rs.getBoolean("damua");
				ds.add(new xacnhanbean(MaChiTietHD, MaHoaDon, makh, hoten, tensach, SoLuongMua, gia, ThanhTien, NgayMua, damua));
			}
			//B4 Dong rs vaf cn
			rs.close();
			cs.cn.close();
			return ds;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	public static void xacnhanmua(String macthd) {
		try {
			CoSodao cs= new CoSodao();
			cs.ketnoi();
			//B2 lay du lieu ve
			PreparedStatement stmt = cs.cn.prepareStatement("update ChiTietHoaDon set damua= 1where MaChiTietHD=?");
			stmt.setString(1, macthd);
			stmt.executeUpdate();
			//B4 Dong rs vaf cn
			cs.cn.close();
			
		} catch (Exception e) {
			e.printStackTrace();

		}
		
	}
}