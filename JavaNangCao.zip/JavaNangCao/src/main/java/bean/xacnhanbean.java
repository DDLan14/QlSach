package bean;

import java.sql.Date;

public class xacnhanbean {
	private String MaChiTietHD;
	private String MaHoaDon;
	private String makh;
	private String hoten;
	private String tensach;
	private long SoLuongMua;
	private long gia;
	private long ThanhTien;
	private Date NgayMua;
	private boolean damua;
	public xacnhanbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public xacnhanbean(String maChiTietHD, String maHoaDon, String makh, String hoten, String tensach, long soLuongMua,
			long gia, long thanhTien, Date ngayMua, boolean damua) {
		super();
		this.MaChiTietHD = maChiTietHD;
		this.MaHoaDon = maHoaDon;
		this.makh = makh;
		this.hoten = hoten;
		this.tensach = tensach;
		this.SoLuongMua = soLuongMua;
		this.gia = gia;
		this.ThanhTien = thanhTien;
		this.NgayMua = ngayMua;
		this.damua = damua;
	}
	public String getMaChiTietHD() {
		return MaChiTietHD;
	}
	public void setMaChiTietHD(String maChiTietHD) {
		this.MaChiTietHD = maChiTietHD;
	}
	public String getMaHoaDon() {
		return MaHoaDon;
	}
	public void setMaHoaDon(String maHoaDon) {
		this.MaHoaDon = maHoaDon;
	}
	public String getMakh() {
		return makh;
	}
	public void setMakh(String makh) {
		this.makh = makh;
	}
	public String getHoten() {
		return hoten;
	}
	public void setHoten(String hoten) {
		this.hoten = hoten;
	}
	public String getTensach() {
		return tensach;
	}
	public void setTensach(String tensach) {
		this.tensach = tensach;
	}
	public long getSoLuongMua() {
		return SoLuongMua;
	}
	public void setSoLuongMua(long soLuongMua) {
		this.SoLuongMua = soLuongMua;
	}
	public long getGia() {
		return gia;
	}
	public void setGia(long gia) {
		this.gia = gia;
	}
	public long getThanhTien() {
		return ThanhTien;
	}
	public void setThanhTien(long thanhTien) {
		this.ThanhTien = thanhTien;
	}
	public Date getNgayMua() {
		return NgayMua;
	}
	public void setNgayMua(Date ngayMua) {
		this.NgayMua = ngayMua;
	}
	public boolean isDamua() {
		return damua;
	}
	public void setDamua(boolean damua) {
		this.damua = damua;
	}
	
	
}