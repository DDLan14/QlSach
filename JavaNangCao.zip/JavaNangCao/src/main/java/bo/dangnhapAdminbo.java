package bo;

import dao.dangnhapAdmindao;
import bean.dangnhapAdminbean;

public class dangnhapAdminbo {
	dangnhapAdmindao dndao=new dangnhapAdmindao();
	  public dangnhapAdminbean ktdn(String tendn, String pass) {
		  return dndao.getkh(tendn, pass);
	  }
}