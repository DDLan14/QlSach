package bo;

import java.util.ArrayList;

import bean.chitiethoadonbean;
import dao.chitiethoadondao;

public class chitiethoadonbo {
	chitiethoadondao cthddao = new chitiethoadondao();
	ArrayList<chitiethoadonbean> ds;
	public ArrayList<chitiethoadonbean> getcthd(String key){
		 ds=cthddao.gethd(key);
		 return ds;
	 }
	 public void themhd(chitiethoadonbean cthd) {
		 cthddao.addcthd(cthd);
	 }
}
