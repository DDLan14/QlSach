package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.lichsubean;



public class lichsudao {
	public ArrayList<lichsubean> dscthoadon = new ArrayList<lichsubean>();
	public ArrayList<lichsubean> getlichsu(String key){
		try {
			//B1 Ket noi csdl
			CoSodao cs= new CoSodao();
			cs.ketnoi();
			//B2 lay du lieu ve
			String sql="select * from VLichSu";
			PreparedStatement cmd= cs.cn.prepareStatement(sql);
			ResultSet rs= cmd.executeQuery();
			//B3 Duyet qua du lieu va lay ve
			while(rs.next()) {
				String makh=rs.getString("makh");
				String tensach=rs.getString("tensach");
				Long SoLuongMua=rs.getLong("SoLuongMua");
				Long gia=rs.getLong("gia");
				Long thanhtoan=rs.getLong("Thanh Toan");			
				Boolean damua=rs.getBoolean("damua");
				if(key.equals(makh))
				dscthoadon.add(new lichsubean(makh, tensach, SoLuongMua, gia, thanhtoan, damua));
			}
			//B4 Dong rs vaf cn
			rs.close();
			cs.cn.close();
			return dscthoadon;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	
}