package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.khachhangbean;
import bo.khachhangbo;

/**
 * Servlet implementation class ktdk
 */
@WebServlet("/ktdk")
public class ktdk extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ktdk() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String HotenKH = request.getParameter("HotenKH") ;
		String TenDN = request.getParameter("TenDN");
		String Matkhau = request.getParameter("Matkhau");
		String Matkhaunhatrlai = request.getParameter("Matkhaunhatrlai");
		String Email = request.getParameter("Email");
		String Diachi = request.getParameter("Diachi");
		String Dienthoai = request.getParameter("Dienthoai");
		khachhangbo kh = new khachhangbo();
		
		kh.getkh();
		if(HotenKH!=null && TenDN!=null && Matkhau!=null && Matkhaunhatrlai!=null && Email!=null && Diachi!=null && Dienthoai!=null)
		{
			if(!Matkhau.equals(Matkhaunhatrlai)|| kh.Tim(TenDN)!=null)
			{
				response.sendRedirect("dangky");
				return;
			
			}
				//RequestDispatcher rd = request.getRequestDispatcher("sach");
				//rd.forward(request, response);
			
			HttpSession session = request.getSession();
			
			//if(session.getAttribute("dn")==null)
			khachhangbean khnew = new khachhangbean(HotenKH, Diachi, Dienthoai, Email, TenDN, Matkhau);
			session.setAttribute("dn", khnew);
			kh.themkh(khnew);
			response.sendRedirect("sach");
		}
		else
		response.sendRedirect("dangky");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
