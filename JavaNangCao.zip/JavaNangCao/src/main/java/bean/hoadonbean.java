package bean;

import java.sql.Date;

public class hoadonbean {
	private String Mahd;
	private String Makh;
	private Date NgayMua;
	private Boolean damua;
	
	
	
	public hoadonbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public hoadonbean(String makh, Date ngayMua, Boolean damua) {
		super();
		this.Makh = makh;
		this.NgayMua = ngayMua;
		this.damua = damua;
	}
	public String getMahd() {
		return Mahd;
	}
	public void setMahd(String mahd) {
		Mahd = mahd;
	}
	public String getMakh() {
		return Makh;
	}
	public void setMakh(String makh) {
		Makh = makh;
	}
	public Date getNgayMua() {
		return NgayMua;
	}
	public void setNgayMua(Date ngayMua) {
		NgayMua = ngayMua;
	}
	public Boolean getDamua() {
		return damua;
	}
	public void setDamua(Boolean damua) {
		this.damua = damua;
	}
	
}

